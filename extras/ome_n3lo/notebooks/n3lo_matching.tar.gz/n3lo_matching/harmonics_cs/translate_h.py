# -*- coding: utf-8 -*-

import pathlib

fps = pathlib.Path(__file__).parent.glob("*.c")
out = {}
for fp in fps:
    with open(fp) as oi:
        nls = []
        # translate
        for l in oi:
            l = l.replace("Power", "np.power")
            l = l.replace("Complex", "complex")
            l = l.replace("List", "list")
            # HERE WE ARE MAKING a MISTAKE
            l = l.replace("HurwitzLerchPhi", "mp.lerchphi")
            l = l.replace("LerchPhi", "mp.lerchphi")
            # Beta have arguments orderder in different ways ... 
            l = l.replace("Beta(0.5,1. + n,0.)", "mp.betainc(1.0 + n, 0.0, x2=0.5)")
            l = l.replace("Beta(0.5,2. + n,0.)", "mp.betainc(2.0 + n, 0.0, x2=0.5)")
            l = l.replace("Beta(0.5,3. + n,0.)", "mp.betainc(3.0 + n, 0.0, x2=0.5)")
            l = l.replace("Beta(0.5,4. + n,0.)", "mp.betainc(4.0 + n, 0.0, x2=0.5)")
            l = l.replace("Beta(0.5,5. + n,0.)", "mp.betainc(5.0 + n, 0.0, x2=0.5)")
            l = l.replace("Beta(0.5,6. + n,0.)", "mp.betainc(6.0 + n, 0.0, x2=0.5)")
            l = l.replace("Beta(2.,1. + n,0.)","mp.betainc(1.0 + n, 0.0, x2=2.0)")
            l = l.replace("Hypergeometric2F1", "mp.hyp2f1")
            l = l.replace("HypergeometricPFQ", "mp.hyper")
            l = l.replace("Cot", "1/np.tan")
            l = l.replace("Sin", "np.sin")
            l = l.replace("Cos", "np.cos")
            l = l.replace("S(1.0, n)", "S1")
            l = l.replace("S(2.0, n)", "S2")
            l = l.replace("S(3.0, n)", "S3")
            nls.append(l)
        out[fp.stem] = nls

# output
with open("../../N3PDF/eko/src/eko/matching_conditions/n3lo/h_functions2.py", "w") as oo:
    oo.write(
        "# -*- coding: utf-8 -*-\n\"\"\"This module contains some approximations for 5th order harmonics sum`\"\"\"\n"
    )
    oo.write("import numba as nb\n")
    oo.write("import numpy as np\n")
    oo.write("import mpmath as mp\n")
    oo.write("\n\n")
        
    for fp, nls in out.items():
        oo.write('@nb.njit("c16(c16,c16,c16)", cache=True)\n')
        oo.write(f"def {fp}(n, S1, S2):\n")
        oo.write(f"\treturn complex(")
        for l in nls:
            oo.write(l)
        oo.write(")\n\n")
