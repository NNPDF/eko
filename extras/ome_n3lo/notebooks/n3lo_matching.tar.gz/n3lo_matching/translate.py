# -*- coding: utf-8 -*-

import pathlib

fps = pathlib.Path(__file__).parent.glob("*.c")
out = {}
for fp in fps:
    with open(fp) as oi:
        nls = []
        # translate
        for l in oi:
            l = l.replace("Power", "np.power")
            l = l.replace("Log", "np.log")
            l = l.replace("NF", "nf")
            l = l.replace("N", "n")
            l = l.replace("ln2", "np.log(2)")
            l = l.replace("EulerGamma", "np.euler_gamma")
            l = l.replace("aQg3", "A_Hgstfac_3(n, sx, smx, s3x, s4x, nf, L)")
            l = l.replace("aggQ3", "A_ggTF2_3(n, sx, smx, s3x, s4x, nf, L)")
            for n in [3,4,5,6,8,18,19,21,22]:
                l = l.replace(f"g{n}", f"gf.mellin_g{n}")
            for n in [9,10,11,12,13,14,16,17,18,19,20,21]:
                l = l.replace(f"F{n}", f"ff.F{n}")
            nls.append(l)
        out[fp.stem] = nls

    # output
    with open(f"../NN3PDF/eko/src/eko/matching_conditions/n3lo/{fp.stem}.py", "w") as oo:
        oo.write(
            f"# -*- coding: utf-8 -*-\n\"\"\"This module contains the |OME| {fp.stem}, the experssions are taken from :cite:`Bierenbaum_2009`\"\"\"\n"
        )
        oo.write("import numba as nb\n")
        oo.write("import numpy as np\n")
        oo.write("\n\n")

        
       
        oo.write('@nb.njit("c16(c16,c16[:],c16[:],c16[:],c16[:],u4,f8)", cache=True)\n')
        oo.write(f"def A_{fp.stem[1:]}_3(n, sx, smx, s3x, s4x, nf, L):\n")
        oo.write(f"\tS1, S2, S3, S4, S5 = sx[0], sx[1], sx[2], sx[3], sx[4]\n")
        oo.write(f"\tSm1, Sm2, Sm3, Sm4 = smx[0], smx[1], smx[2], smx[3] \n")
        oo.write(f"\tS21, S2m1, Sm21, Sm2m1 = s3x[0], s3x[1], s3x[2], s3x[3] \n")
        oo.write(f"\tS31, S211, Sm22, Sm211, Sm31 = s4x[0], s4x[1], s4x[2], s4x[3],s4x[4]\n")
        oo.write(f"\treturn ")
        for l in nls:
            oo.write(l)
        oo.write("\n\n")


##########################
# to add at Hq
#########################

    # S1, S2, S3, S4 = sx[0], sx[1], sx[2], sx[3]
    # _, Sm2, Sm3, Sm4 = smx[0], smx[1], smx[2], smx[3]
    # S21, _, Sm21 = s3x[0], s3x[1], s3x[2]
    # S31, S211, Sm22, Sm211, Sm31 = s4x[0], s4x[1], s4x[2], s4x[3], s4x[4]
    # H21 = hf.H21(n,S1)
    # H22 = hf.H22()
    # H23 = hf.H23(n,S1)
    # H24 = hf.H24()
    # H25 = hf.H25()
    # S1l05 = cs.S1l05(n)
    # S111l211 = cs.S111l211(H24)
    # S12l21 = cs.S12l21(H25)
    # S21l21 = cs.S21l21(n,S1)
    # S3l2 = cs.S3l2(n)
    # S1111l20511 = cs.S1111l20511(n,S1)
    # S1111l21051 = cs.S1111l21051(n,S1,H21)
    # # S1111l21105 = cs.S1111l21105(n,S1,H21,H22,H23,H24)
    # # S112l2051 = cs.S112l2051(n,S1)
    # # S112l2105 = cs.S112l2105(n,S1,S2, H21,H23)
    # S121l2051 = cs.S121l2051(n,S1,H23)
    # # S121l2105 = cs.S121l2105(n,S1,S2,H23,H25)
    # # S13l205 = cs.S13l205(n,S1,S2,S3)
    # S31l205 = cs.S31l205(n,S1,S2,S3)
    # H26 = hf.H26(n,S1,S2)
    # H27 = hf.H27(n,S1,S2,S3,H21,H22,H23,H24,H25)

##########################
# to add at qqNS
#########################

# from . import s_functions as sf

# @nb.njit("c16(c16,c16[:],c16[:],c16[:],c16[:],u4,f8)", cache=True)
# def A_qqNS_3(n, sx, smx, s3x, s4x, nf, L):
#     S1, S2, S3, S4, S5 = sx[0], sx[1], sx[2], sx[3], sx[4]
#     Sm1, Sm2, Sm3, Sm4, Sm5 = smx[0], smx[1], smx[2], smx[3], smx[4]
#     S21, S2m1, Sm21 = s3x[0], s3x[1], s3x[2]
#     S31, S211, Sm22, Sm211 = s4x[0], s4x[1], s4x[2], s4x[3]
#     S41 = sf.harmonic_S41(n, S1, S2, S3)
#     S311 = sf.harmonic_S311(n, S1, S2)
#     S221 = sf.harmonic_S221(n, S1, S2, S21)
#     Sm221 = sf.harmonic_Sm221(n, S1, Sm1, S21, Sm21)
#     S21m2 = sf.harmonic_S21m2(n, S1, S2, Sm1, Sm2, Sm3, S21, Sm21, S2m1)
#     S2111 =  sf.harmonic_S2111(n, S1, S2, S3)
#     Sm2111 = sf.harmonic_Sm2111(n, S1, S2, S3, Sm1)
#     S23 = sf.harmonic_S23(n, S1, S2, S3)
#     Sm23 = sf.harmonic_Sm23(n, Sm1, Sm2, Sm3)
#     S2m3 = sf.harmonic_S2m3(n, S2, Sm1, Sm2, Sm3)