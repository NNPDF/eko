# -*- coding: utf-8 -*-

import pathlib

fps = pathlib.Path(__file__).parent.glob("*.c")
out = {}
for fp in fps:
    with open(fp) as oi:
        nls = []
        # translate
        for l in oi:
            l = l.replace("Sigma_Summation_Objects_Private_MyPower","np.power")
            l = l.replace("Power", "np.power")
            l = l.replace("Log", "np.log")
            l = l.replace("ln2", "np.log(2)")
            l = l.replace("EulerGamma", "np.euler_gamma")
            l = l.replace("S(1.,n)", "S1")
            l = l.replace("S(2.,n)", "S2")
            l = l.replace("S(3.,n)", "S3")
            nls.append(l)
        out[fp.stem] = nls

# output
with open("../../N3PDF/eko/src/eko/matching_conditions/n3lo/f_functions2.py", "w") as oo:
    oo.write(
        "# -*- coding: utf-8 -*-\n"
    )
    oo.write("import numba as nb\n")
    oo.write("import numpy as np\n")
    oo.write("from ...anomalous_dimensions.harmonics import mellin_g3\n")
    oo.write("from .g_functions import mellin_g18\n")
    oo.write("\n\n")
        
    for fp, nls in out.items():
        oo.write('@nb.njit("c16(c16,c16,c16,c16)", cache=True)\n')
        oo.write(f"def {fp}(n, S1, S2, S3):\n")
        oo.write(f"\treturn ")
        for l in nls:
            oo.write(l)
        oo.write("\n\n")
