## EKO: aN3LO DGLAP evolution benchmark tables

This folder contains the EKO benchmark tables obtained 
with the settings specified in:

    Add here a link to arxiv.

aN3LO evolution is performed in 2 different schemes FFNS (nf=4),
and VFNS (nf=3 .. 5) with NNLO matrix elements using the EKO 
code:

    https://github.com/NNPDF/eko

Both results with the FHMRUVV splitting function approximation 
and EKO approximation are provided.

The ``central`` tables contains results for central scale with 
$\mu_F = \mu_R$, while for the scale varied results are stored in
$\mu_R = 0.5 \mu_F$ (``down``), $\mu_R = 2 \mu_F$ (``up``) respectively. 

Within each approximation, each table is obtained varying a 
single splitting function a the time. The file naming follows 
the convention:

    ``(var_gg, var_gq, var_qg, var_qq, var_nsp, var_nsm, var_nsv)``

where the central prediction is always labelled with ``0``. 
(i.e the unvaried splitting function evolution is stored in: 
``0-0-0-0-0-0-0``).

For each point in x, uncertainties, due to splitting function approximation, 
can be obtained by taking the envelop over all the possible variations
(asymmetric error) or taking 1/2 of the of the spread of all the final 
PDF (symmetric error).
