(* ::Package:: *)

DefineSinfTable["https://www3.risc.jku.at/research/combinat/software/HarmonicSums/RelTabSinfH1.m"];
DefineCSinfTable["https://www3.risc.jku.at/research/combinat/software/HarmonicSums/RelTabCSinf.m"];

InvMellinRules={
	InvMellinProblem[1/(1.` +1.` n),n,x] -> 1, 
	InvMellinProblem[1/(2.` +1.` n),n,x] -> x, 
	InvMellinProblem[1/(3.` +1.` n),n,x] -> x^2, 
	InvMellinProblem[1/(4.` +1.` n),n,x] -> x^3,
	InvMellinProblem[1/(5.` +1.` n),n,x] -> x^4,
	InvMellinProblem[S[1,n]/(1.` +1.` n),n,x] -> Log[1-x],
	InvMellinProblem[S[2,n]/(1.` +1.` n),n,x] -> Log[1-x] Log[x]-Log[x]^2/2+PolyLog[2,x],
	InvMellinProblem[S[3,n]/(1.` +1.` n),n,x] -> 1/3! Log[x]^3 + H[1,0,0,x],
	InvMellinProblem[S[4,n]/(1.` +1.` n),n,x] -> - 1/4! Log[x]^4 - H[1,0,0,0,x],
	InvMellinProblem[S[1,n]/(2.` +1.` n),n,x] -> -1+x-x Log[1-x]+x Log[x],
	InvMellinProblem[1/(1.` +1.` n)^7,n,x] -> Log[x]^6,
	InvMellinProblem[1/(1.` +1.` n)^6,n,x] -> Log[x]^5,
	InvMellinProblem[1/(1.` +1.` n)^5,n,x] -> Log[x]^4,
	InvMellinProblem[1/(1.` +1.` n)^4,n,x] -> Log[x]^3,
	InvMellinProblem[1/(1.` +1.` n)^3,n,x] -> Log[x]^2,
	InvMellinProblem[1/(1.` +1.` n)^2,n,x] -> Log[x],
	InvMellinProblem[S[1,n]/(1.` +1.` n)^2,n,x] -> -(1/2) Log[x]^2-PolyLog[2,x]+Zeta[2],
	InvMellinProblem[S[2,n]/(1.` +1.` n)^2,n,x] -> 1/3! Log[x]^3+H[0,1,0,x]+2 Zeta[3],
	InvMellinProblem[S[1,n]/(2.` +1.` n)^3,n,x] -> -1+x-x z3+x 1/3! Log[x]^3 +x H[0,0,1,x]-x Log[x]-x z2 Log[x]+1/2 x Log[x]^2,
	InvMellinProblem[S[1,n]/(3.` +1.` n),n,x] -> -(1/2)-x+(3 x^2)/2-x^2 Log[1-x] +x^2 Log[x],
	InvMellinProblem[1/(2.`+ 1.`n)^4,n,x] -> -x 1/3! Log[x]^3,
	InvMellinProblem[1/(2.`+ 1.`n)^3,n,x] -> 1/2 x Log[x]^2,
	InvMellinProblem[1/(2.`+ 1.`n)^2,n,x] -> - x Log[x],
	InvMellinProblem[S[1,n]/(1.` +1.` n)^3,n,x] ->  1/3! Log[x]^3 +H[0,0,1,x] -Log[x] Zeta[2]-Zeta[3],
	InvMellinProblem[S[1,n]/(1.` +1.` n)^4,n,x] ->  (2 Zeta[2]^2)/5-1/4! Log[x]^4 +Zeta[3] Log[x]+1/2 Zeta[2] Log[x]^2-PolyLog[4,x],
	InvMellinProblem[1/(2 + n)^2,n,x] -> -x Log[x],
	InvMellinProblem[S[1,n]/(2.` +1.` n)^2,n,x] -> -x+x^2-x^2 Log[x]-1/2 x^2 Log[x]^2-x^2 PolyLog[2,x]+x^2 Zeta[2],
	InvMellinProblem[(1/2 S[1,n]^2+1/2 S[2,n])/(1.` +1.` n),n,x] -> -Zeta[2]+H[1,1,x]+PolyLog[2,x],
	InvMellinProblem[Lm16[1+n],n,x] -> Log[1-x]^6,
	InvMellinProblem[Lm15[1+n],n,x] -> Log[1-x]^5,
	InvMellinProblem[Lm14[1+n],n,x] -> Log[1-x]^4,
	InvMellinProblem[Lm13[1+n],n,x] -> Log[1-x]^3,
	InvMellinProblem[Lm12[1+n],n,x] -> Log[1-x]^2,
	InvMellinProblem[Lm11[1+n],n,x] -> Log[1-x],
	InvMellinProblem[Lm14m1[1+n],n,x] -> (1-x)Log[1-x]^4,
	InvMellinProblem[Lm13m1[1+n],n,x] -> (1-x)Log[1-x]^3,
	InvMellinProblem[Lm12m1[1+n],n,x] -> (1-x)Log[1-x]^2,
	InvMellinProblem[Lm11m1[1+n],n,x] -> (1-x)Log[1-x],
	InvMellinProblem[Lm14[2+n],n,x] -> 24 x H[1,1,1,1,x],
	InvMellinProblem[Lm13[2+n],n,x] -> -6 x H[1,1,1,x],
	InvMellinProblem[Lm12[2+n],n,x] -> 2 x H[1,1,x],
	InvMellinProblem[Lm11[2+n],n,x] -> x Log[1-x]
}; 

Ht[-1,0,x] := H[-1,0,x] + Zeta[2]/2;
Ht[1,0,x] := H[1,0,x] + Zeta[2];
Ht[1,0,0,x] := H[1,0,0,x] - Zeta[3];
Ht[0,-1,0,x] := H[0,-1,0,x] + H[0,x] Zeta[2]/2 + 3 Zeta[3]/2;
Ht[0,1,0,x] := H[0,1,0,x] + H[0,x] Zeta[2] + 2 Zeta[3];


HarmonicRules={
 Zeta[n__, a__] -> PolyGamma[n-1, a]/Factorial[n-1](-1)^(-n),
 PolyGamma[0, n__] -> S[1, - 1 + n] - EulerGamma,
 PolyGamma[1, n__] -> - S[2, - 1 + n] + Zeta[2],
 PolyGamma[2, n__] -> 2 S[3, - 1 + n] - 2 Zeta[3],
 PolyGamma[3, n__] -> - 6 S[4, - 1 + n] + 6 Zeta[4],
 PolyGamma[4, n__] -> 24 S[5, - 1 + n] - 24 Zeta[5],
 PolyGamma[5, n__] -> - 120 S[6, - 1 + n] + 120 Zeta[6],
 PolyGamma[6, n__] -> 720 S[7, - 1 + n] - 720 Zeta[7]
};

ZetaRules = {z2 -> Zeta[2], z3 -> Zeta[3], z4 -> Zeta[4], z5 -> Zeta[5], z6 -> Zeta[6], z7 -> Zeta[7]};

hrep={
	H[0,0,0,x]  -> 1/3! Log[x]^3,
	H[0,0,0,0,x]  -> 1/4! Log[x]^4,
	H[0,0,0,0,0,x]  -> 1/5! Log[x]^5,
	H[0,0,0,0,0,0,x]  -> 1/6! Log[x]^6,
	H[1,x] -> - Log[1-x],
	H[1,1,x] ->  1/2 Log[1-x]^2, 
	H[0,x]->Log[x],H[2,x]->Log[2]-Log[2-x],H[0,-1,x]->-PolyLog[2,-x],H[0,0,x]->Log[x]^2/2,H[0,1,x]->PolyLog[2,x],H[0,2,x]->\[Pi]^2/6+Log[-(2/(-2+x))] Log[x/2]-PolyLog[2,1-x/2],H[1,0,x]->-Log[1-x] Log[x]-PolyLog[2,x],H[2,0,x]->1/6 (\[Pi]^2+3 Log[2]^2-3 Log[2-x]^2+6 I \[Pi] Log[1-x/2]-6 PolyLog[2,-(2/(-2+x))]),H[2,2,x]->1/2 (Log[2]-Log[2-x])^2,H[0,0,2,x]->PolyLog[3,x/2],H[0,2,0,x]->Log[x] PolyLog[2,x/2]-2 PolyLog[3,x/2],H[0,2,1,x]->1/12 \[Pi]^2 Log[2]-1/2 I \[Pi] Log[2]^2+Log[2]^2 Log[1-x]+1/2 Log[2] Log[1-x]^2-Log[2] Log[1-x] Log[2-x]+1/2 I \[Pi] Log[2-x]^2+1/12 \[Pi]^2 Log[x]+2 Log[1-x] Log[2-x] Log[x]+Log[2-2 x] PolyLog[2,1-x]+Log[2-x] PolyLog[2,2-x]-Log[2] PolyLog[2,1-x/2]+Log[2-x] PolyLog[2,1-x/2]+Log[2] PolyLog[2,(-2+x)/(2 (-1+x))]+Log[1-x] PolyLog[2,(-2+x)/(2 (-1+x))]-Log[2-x] PolyLog[2,(-2+x)/(2 (-1+x))]-Log[2] PolyLog[2,(-2+x)/(-1+x)]-Log[1-x] PolyLog[2,(-2+x)/(-1+x)]+Log[2-x] PolyLog[2,(-2+x)/(-1+x)]+Log[x] PolyLog[2,-1+x]+Log[x] PolyLog[2,x]+Log[2-x] PolyLog[2,-(x/(-2+x))]-Log[x] PolyLog[2,-(x/(-2+x))]-Log[2-x] PolyLog[2,x/(-2+x)]+Log[x] PolyLog[2,x/(-2+x)]-PolyLog[3,1-x]-PolyLog[3,2-x]-PolyLog[3,1-x/2]+PolyLog[3,(-2+x)/(2 (-1+x))]-PolyLog[3,(-2+x)/(-1+x)]-PolyLog[3,x]+PolyLog[3,-(x/(-2+x))]-PolyLog[3,x/(-2+x)]+(11 Zeta[3])/4,H[0,2,2,x]->1/2 (-((I \[Pi]^3)/3)+2 I \[Pi] Log[2]^2+Log[2]^3-1/3 \[Pi]^2 Log[16]-2 I \[Pi] Log[2] Log[2-x]+\[Pi]^2 Log[2/x]-Log[2-x]^2 Log[2/x]+\[Pi]^2 Log[x]-2 I \[Pi] Log[2] Log[x]+2 I \[Pi] Log[2-x] Log[x]-Log[2-x]^2 Log[x]+2 Log[2-x] Log[1-x/2] Log[x]+2 Log[1-x/2] Log[-(2/(-2+x))] Log[x]+Log[-(2/(-2+x))]^2 Log[x]+2 (I \[Pi]+Log[2-x]) PolyLog[2,1-x/2]+(2 I \[Pi]+Log[4]) PolyLog[2,x/2]-2 PolyLog[3,1-x/2]+2 Zeta[3]),H[2,0,0,x]->1/2 Log[-(2/(-2+x))] Log[x]^2-Log[x] PolyLog[2,x/2]+PolyLog[3,x/2],H[2,0,1,x]->(I \[Pi]^3)/6-1/12 \[Pi]^2 Log[2]+1/2 I \[Pi] Log[2]^2-Log[2]^2 Log[1-x]-1/2 Log[2] Log[1-x]^2+Log[2] Log[1-x] Log[2-x]-I \[Pi] Log[1-x] Log[x]-Log[1-x] Log[2-x] Log[x]-(I \[Pi]+Log[2-2 x]) PolyLog[2,1-x]-Log[1-x/2] PolyLog[2,1-x/2]-Log[2] PolyLog[2,(-2+x)/(2 (-1+x))]-Log[1-x] PolyLog[2,(-2+x)/(2 (-1+x))]+Log[2-x] PolyLog[2,(-2+x)/(2 (-1+x))]+Log[2] PolyLog[2,(-2+x)/(-1+x)]+Log[1-x] PolyLog[2,(-2+x)/(-1+x)]-Log[2-x] PolyLog[2,(-2+x)/(-1+x)]-I \[Pi] PolyLog[2,x]-Log[2-x] PolyLog[2,x]+PolyLog[3,1-x]+PolyLog[3,1-x/2]-PolyLog[3,(-2+x)/(2 (-1+x))]+PolyLog[3,(-2+x)/(-1+x)]-(15 Zeta[3])/8,H[2,0,2,x]->Log[2]^3-Log[2-x] Log[-(4/(-2+x))] Log[2/x]-Log[2]^2 Log[x]+Log[-(2/(-2+x))] (2 PolyLog[2,1-x/2]+PolyLog[2,x/2])+2 PolyLog[3,1-x/2]-2 Zeta[3],H[2,1,0,x]->(I \[Pi]^3)/6-1/6 \[Pi]^2 Log[2]-1/6 \[Pi]^2 Log[1-x]+\[Pi]^2 Log[2-x]-I \[Pi] Log[1-x] Log[2-x]+3/2 Log[1-x]^2 Log[2-x]+1/6 \[Pi]^2 Log[-(2/(-2+x))]-I \[Pi] Log[2-x] Log[x]-Log[1-x] Log[2-x] Log[x]+1/2 I \[Pi] Log[x]^2+Log[-1+2/x] PolyLog[2,-1+2/x]+Log[2-x] PolyLog[2,1/(1-x)]-I \[Pi] PolyLog[2,2-x]+Log[1-x] PolyLog[2,2-x]-Log[2-x] PolyLog[2,2-x]-I \[Pi] PolyLog[2,-1+x]+Log[1-x] PolyLog[2,-1+x]-Log[2-x] PolyLog[2,(-2+x)/x]+Log[x] PolyLog[2,(-2+x)/x]-Log[x] PolyLog[2,x]-PolyLog[3,-1+2/x]+PolyLog[3,2-x]+PolyLog[3,(-2+x)/x]+PolyLog[3,x]-(7 Zeta[3])/8,H[2,1,1,x]->-(1/2) Log[1-x]^2 Log[2-x]-Log[1-x] PolyLog[2,-1+x]+PolyLog[3,-1+x]+(3 Zeta[3])/4,H[2,2,0,x]->1/6 (-Log[2]^3+Log[2-x]^3-(\[Pi]^2+3 Log[2]^2) Log[1-x/2]-3 I \[Pi] Log[-(2/(-2+x))]^2)-PolyLog[3,-(2/(-2+x))]+Zeta[3],H[2,2,1,x]->-(1/12) \[Pi] (-6 I Log[2-x]^2+\[Pi] Log[-(-2+x)^3])+PolyLog[3,2-x]-(7 Zeta[3])/8,H[2,2,2,x]->1/6 (Log[2]-Log[2-x])^3,H[0,-1,-1,0,x]->-(1/2) (Log[x] Log[1+x]+PolyLog[2,-x])^2+Log[x] (1/2 Log[-x] Log[1+x]^2-1/2 Log[x] Log[1+x]^2+Log[1+x] (Log[x] Log[1+x]+PolyLog[2,-x])+Log[1+x] PolyLog[2,1+x]-PolyLog[3,1+x]+Zeta[3]),H[0,-1,0,0,x]->1/2 Log[x]^2 PolyLog[2,-x]+Log[x]^2 (Log[x] Log[1+x]+PolyLog[2,-x])-2 Log[x] (1/2 Log[x] PolyLog[2,-x]+1/2 Log[x] (Log[x] Log[1+x]+PolyLog[2,-x])-PolyLog[3,-x])-3 PolyLog[4,-x],H[0,0,-1,0,x]->-(1/2) Log[x]^2 PolyLog[2,-x]-1/2 Log[x]^2 (Log[x] Log[1+x]+PolyLog[2,-x])+Log[x] (1/2 Log[x] PolyLog[2,-x]+1/2 Log[x] (Log[x] Log[1+x]+PolyLog[2,-x])-PolyLog[3,-x])+3 PolyLog[4,-x],H[0,0,0,1,x]->PolyLog[4,x],H[0,0,1,1,x]->PolyLog[2,2,x],H[0,1,0,0,x]->1/2 Log[x]^2 PolyLog[2,x]-2 Log[x] PolyLog[3,x]+3 PolyLog[4,x],H[0,1,0,1,x]->1/2 PolyLog[2,x]^2-2 PolyLog[2,2,x],H[0,1,1,1,x]->\[Pi]^4/90-1/6 Log[1-x]^3 Log[x]-1/2 Log[1-x]^2 PolyLog[2,1-x]+Log[1-x] PolyLog[3,1-x]-PolyLog[4,1-x]};

QCDConstantsRules = {
	ca -> 3, 
	nc -> 3, 
	cf -> 4/3,
	tr -> 1/2,
	d4RA/nr -> 5/2, (*(nc^2+6)(nc^2-1)/48,*)
	d4RR/nr -> 5/36, (*(nc^4 - 6nc^2 + 18)(nc^2-1)/ (96 nc^3),*)
	d4AA/na -> nc^2(nc^2 + 36) / 24,
	d4RA/na -> nc (nc^2 + 6) / 48,
	d4RR/na -> (nc^4 - 6nc^2 + 18) / (96 nc^2),
	caf -> (ca - cf)
};

LargeNcQCDConstantsRules = {
	ca -> 3, 
	nc -> 3, 
	cf -> 3/2,
	tr -> 1/2,
	d4RA/nr -> nc^4/48,
	d4RR/nr -> nc^3/96,
	d4AA/na -> nc^4/ 24,
	d4RA/na -> nc^3/ 48,
	d4RR/na -> nc^2/ 96
};

BetaRules={
	beta0 -> 11/3 ca \[Minus] 2/3 nf,
	beta1 -> 34/3 ca^2 \[Minus] 10/3 ca nf \[Minus] 2 cf nf, 
	beta2 -> (
        2857/54 ca^3
        - 1415/27 ca^2 tr nf
        - 205/9 cf ca tr nf
        + 2 cf^2 tr nf
        + 44/9 cf (tr nf)^2
        + 158/27 ca (tr nf)^2
    )
};


(* Single argument harmonic sum*)
harmonics = {
 S[1, n] -> S1,  S[2, n] -> S2, S[3, n] -> S3, S[4, n] -> S4, S[5, n] -> S5,
 S[1, n/2] -> Sp1p, S[2, n/2] -> Sp2p, S[3, n/2] -> Sp3p, S[4, n/2] -> Sp4p, S[5, n/2] -> Sp5p
};

harmonicminus = {
S[-1,n] -> Sm1, S[-2,n] -> Sm2, S[-3,n] -> Sm3, S[-4,n] -> Sm4, S[-5,n] -> Sm5
};
(* Multiple argument harmonic sum*)
harmonics234 = {
(* 2nd order *)
S[1,1,n] -> 1/2 (S[1,n]^2 + S[2,n]), 

(* 3rd order *)
S[1,1,1,n] -> 1/6(S[1,n]^3 + 3 S[1,n]S[2,n] +2 S[3,n]),
S[1,-2,n] -> - Sm21 + S[-3, n] + S[-2, n] S[1,n],
S[1,2,n] -> - S21 + S[3,n] + S[2,n] S[1,n],
S[-2,-1,n] -> Sm2m1,
S[-2,1,n] -> Sm21,
S[2,-1,n] -> S2m1,
S[2,1,n] -> S21,
 
 (* 4th order *)
 S[-2,-2,n] -> 1/2 (S[-2,n]^2 + S[4,n]),
 S[1,1,-2,n] -> S[-2,1,1,n] + S[-2,n] S[2,n] - S[-2,2,n] - S[-2,n] S[1,1,n] + S[1,n] S[1,-2,n] + S[1,-3,n] - S[1,n] S[-3,n],
 S[1,-3,n] -> - S[-3,1, n] + S[-3,n] S[1,n] + S[-4, n],
 S[1,3,n] -> - S[3,1,n] + S[3,n] S[1,n] + S[4,n],
 S[2,-2, n] -> -S[-2,2, n] + S[-4,n] + S[-2, n] S[2,n],
 S[2,2, n] -> 1/2( S[2,n]^2 + S[4,n]),
 S[-3,1,n] -> Sm31,
 S[-2,2,n] -> Sm22,
 S[3,1,n] -> S31,
 S[-2,1,1,n] -> Sm211,
 S[2,1,1,n] -> S211,
 S[1,1,1,1,n] -> 1/4 S[4,n] +1/8 S[2,n]^2 + 1/3 S[3,n] S[1,n] + 1/4 S[2,n] S[1,n]^2 + 1/24 S[1,n]^4,
 S[1,1,2,n] -> S[2,1,1,n] + 1/2 ((S[1,n](S[1,2,n]-S[2,1,n])) + S[1,3,n]-S[3,1,n]),
 S[1,2,1,n] -> -2 S[2,1,1,n] + S[3,1,n] + S[1,n]S[2,1,n] + S[2,2,n]
};
harmonics5={
 (* 5th order *)
 S[4,1,n] -> S41, 
 S[2,1,-2,n] -> S21m2, 
 S[2,2,1,n] -> S221, 
 S[-2,2,1,n] -> Sm221, 
 S[3,1,1,n] -> S311,
 S[2,1,1,1,n] -> S2111, 
 S[-2,1,1,1,n] -> Sm2111,
 S[2,3,n] -> S23, 
 S[2,-3,n] -> S2m3, 
 S[-2,3,n] -> Sm23
};
