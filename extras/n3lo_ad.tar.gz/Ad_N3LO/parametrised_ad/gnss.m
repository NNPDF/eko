g3nss := N[nf*gqq3nssnf1 + nf^2*gqq3nssnf2 /. QCDConstantsRules /. ZetaRules]
 
gqq3nssnf2 = (160*(40/(1 + n)^6 - 8/(n^6*(1 + n)^6) - 16/(1 + n)^5 - 
       24/(n^5*(1 + n)^5) + 108/(1 + n)^4 + 36/(n^4*(1 + n)^4) + 
       112/(1 + n)^3 + 168/(n^3*(1 + n)^3) + 144/(1 + n)^2 + 
       174/(n^2*(1 + n)^2) - 64/(n*(1 + n)) - 32/(3*(2 + n)^2) - 
       208/(3*(-1 + n)*(2 + n)) + (-16/(1 + n)^3 - 4/(n^3*(1 + n)^3) + 
         4/(1 + n)^2 + 14/(n^2*(1 + n)^2) + 58/(n*(1 + n)) - 
         32/(3*(2 + n)^2) - 256/(3*(-1 + n)*(2 + n)))*S[-3, n] + 
       (24/(1 + n)^4 - 8/(1 + n)^3 + 28/(n^3*(1 + n)^3) + 28/(1 + n)^2 + 
         104/(n^2*(1 + n)^2) + 91/(n*(1 + n)) - 32/(3*(2 + n)^2) - 
         304/(3*(-1 + n)*(2 + n)))*S[-2, n] + 
       (48/(1 + n)^5 + 4/(n^5*(1 + n)^5) + 6/(1 + n)^4 - 24/(n^4*(1 + n)^4) + 
         76/(1 + n)^3 - 162/(n^3*(1 + n)^3) + 50/(1 + n)^2 - 
         164/(n^2*(1 + n)^2) - 285/(2*n*(1 + n)) + 32/(3*(2 + n)^2) + 
         304/(3*(-1 + n)*(2 + n)))*S[1, n] + 
       (-8/(1 + n)^3 - 6/(n^3*(1 + n)^3) - 6/(1 + n)^2 - 7/(n^2*(1 + n)^2) - 
         9/(n*(1 + n)) + 16/((-1 + n)*(2 + n)))*S[3, n] + 
       (-12/(n^2*(1 + n)^2) - 22/(n*(1 + n)) + 32/((-1 + n)*(2 + n)))*
        S[4, n] + (-8/(n^3*(1 + n)^3) - 16/(1 + n)^2 - 28/(n^2*(1 + n)^2) - 
         76/(n*(1 + n)) + 32/(3*(2 + n)^2) + 352/(3*(-1 + n)*(2 + n)))*
        S[-2, 1, n] + (32/(1 + n)^3 + 8/(1 + n)^2 - 56/(n^2*(1 + n)^2) - 
         112/(n*(1 + n)) + 32/(3*(2 + n)^2) + 352/(3*(-1 + n)*(2 + n)))*
        S[1, -2, n] - (-6/(n^4*(1 + n)^4) - 23/(n^3*(1 + n)^3) - 
         28/(n^2*(1 + n)^2) - 13/(n*(1 + n)) + 16/((-1 + n)*(2 + n)))*
        (-S[2, n] + 4*S[1, 1, n]) - (-8/(n*(1 + n)) + 16/((-1 + n)*(2 + n)))*
        (2*S[-2, -2, n] - S[-2, 2, n] + 4*S[-2, 1, 1, n]) + 
       (-4/(n^2*(1 + n)^2) - 10/(n*(1 + n)) + 16/((-1 + n)*(2 + n)))*
        (S[-4, n] + 2*S[-3, 1, n] + 2*S[1, -3, n] - S[1, 3, n] - 
         4*S[1, -2, 1, n]) - (-8/(n^2*(1 + n)^2) - 12/(n*(1 + n)) + 
         16/((-1 + n)*(2 + n)))*(-S[2, -2, n] + S[3, 1, n] + 
         4*S[1, 1, -2, n])))/27
 
QCDConstantsRules = {ca -> 3, nc -> 3, cf -> 4/3, tr -> 1/2, d4RA/nr -> 5/2, 
     d4RR/nr -> 5/36, d4AA/na -> (nc^2*(36 + nc^2))/24, 
     d4RA/na -> (nc*(6 + nc^2))/48, d4RR/na -> (18 - 6*nc^2 + nc^4)/(96*nc^2)}
 
ZetaRules = {z2 -> Pi^2/6, z3 -> Zeta[3], z4 -> Pi^4/90, z5 -> Zeta[5], 
     z6 -> Pi^6/945, z7 -> Zeta[7]}
 
Attributes[z2] = {Constant}
 
N[z2, HarmonicSums`Private`b_:{MachinePrecision, MachinePrecision}] := 
    N[Zeta[2], HarmonicSums`Private`b]
 
Attributes[z3] = {Constant}
 
N[z3, HarmonicSums`Private`b_:{MachinePrecision, MachinePrecision}] := 
    N[Zeta[3], HarmonicSums`Private`b]
 
Attributes[z5] = {Constant}
 
N[z5, HarmonicSums`Private`b_:{MachinePrecision, MachinePrecision}] := 
    N[Zeta[5], HarmonicSums`Private`b]
 
Attributes[z7] = {Constant}
 
N[z7, HarmonicSums`Private`b_:{MachinePrecision, MachinePrecision}] := 
    N[Zeta[7], HarmonicSums`Private`b]
g3nss := N[nf*gqq3nssnf1 + nf^2*gqq3nssnf2 /. QCDConstantsRules /. ZetaRules]
 
gqq3nssnf2 = (160*(40/(1 + n)^6 - 8/(n^6*(1 + n)^6) - 16/(1 + n)^5 - 
       24/(n^5*(1 + n)^5) + 108/(1 + n)^4 + 36/(n^4*(1 + n)^4) + 
       112/(1 + n)^3 + 168/(n^3*(1 + n)^3) + 144/(1 + n)^2 + 
       174/(n^2*(1 + n)^2) - 64/(n*(1 + n)) - 32/(3*(2 + n)^2) - 
       208/(3*(-1 + n)*(2 + n)) + (-16/(1 + n)^3 - 4/(n^3*(1 + n)^3) + 
         4/(1 + n)^2 + 14/(n^2*(1 + n)^2) + 58/(n*(1 + n)) - 
         32/(3*(2 + n)^2) - 256/(3*(-1 + n)*(2 + n)))*S[-3, n] + 
       (24/(1 + n)^4 - 8/(1 + n)^3 + 28/(n^3*(1 + n)^3) + 28/(1 + n)^2 + 
         104/(n^2*(1 + n)^2) + 91/(n*(1 + n)) - 32/(3*(2 + n)^2) - 
         304/(3*(-1 + n)*(2 + n)))*S[-2, n] + 
       (48/(1 + n)^5 + 4/(n^5*(1 + n)^5) + 6/(1 + n)^4 - 24/(n^4*(1 + n)^4) + 
         76/(1 + n)^3 - 162/(n^3*(1 + n)^3) + 50/(1 + n)^2 - 
         164/(n^2*(1 + n)^2) - 285/(2*n*(1 + n)) + 32/(3*(2 + n)^2) + 
         304/(3*(-1 + n)*(2 + n)))*S[1, n] + 
       (-8/(1 + n)^3 - 6/(n^3*(1 + n)^3) - 6/(1 + n)^2 - 7/(n^2*(1 + n)^2) - 
         9/(n*(1 + n)) + 16/((-1 + n)*(2 + n)))*S[3, n] + 
       (-12/(n^2*(1 + n)^2) - 22/(n*(1 + n)) + 32/((-1 + n)*(2 + n)))*
        S[4, n] + (-8/(n^3*(1 + n)^3) - 16/(1 + n)^2 - 28/(n^2*(1 + n)^2) - 
         76/(n*(1 + n)) + 32/(3*(2 + n)^2) + 352/(3*(-1 + n)*(2 + n)))*
        S[-2, 1, n] + (32/(1 + n)^3 + 8/(1 + n)^2 - 56/(n^2*(1 + n)^2) - 
         112/(n*(1 + n)) + 32/(3*(2 + n)^2) + 352/(3*(-1 + n)*(2 + n)))*
        S[1, -2, n] - (-6/(n^4*(1 + n)^4) - 23/(n^3*(1 + n)^3) - 
         28/(n^2*(1 + n)^2) - 13/(n*(1 + n)) + 16/((-1 + n)*(2 + n)))*
        (-S[2, n] + 4*S[1, 1, n]) - (-8/(n*(1 + n)) + 16/((-1 + n)*(2 + n)))*
        (2*S[-2, -2, n] - S[-2, 2, n] + 4*S[-2, 1, 1, n]) + 
       (-4/(n^2*(1 + n)^2) - 10/(n*(1 + n)) + 16/((-1 + n)*(2 + n)))*
        (S[-4, n] + 2*S[-3, 1, n] + 2*S[1, -3, n] - S[1, 3, n] - 
         4*S[1, -2, 1, n]) - (-8/(n^2*(1 + n)^2) - 12/(n*(1 + n)) + 
         16/((-1 + n)*(2 + n)))*(-S[2, -2, n] + S[3, 1, n] + 
         4*S[1, 1, -2, n])))/27
 
QCDConstantsRules = {ca -> 3, nc -> 3, cf -> 4/3, tr -> 1/2, d4RA/nr -> 5/2, 
     d4RR/nr -> 5/36, d4AA/na -> (nc^2*(36 + nc^2))/24, 
     d4RA/na -> (nc*(6 + nc^2))/48, d4RR/na -> (18 - 6*nc^2 + nc^4)/(96*nc^2)}
 
ZetaRules = {z2 -> Pi^2/6, z3 -> Zeta[3], z4 -> Pi^4/90, z5 -> Zeta[5], 
     z6 -> Pi^6/945, z7 -> Zeta[7]}
 
Attributes[z2] = {Constant}
 
N[z2, HarmonicSums`Private`b_:{MachinePrecision, MachinePrecision}] := 
    N[Zeta[2], HarmonicSums`Private`b]
 
Attributes[z3] = {Constant}
 
N[z3, HarmonicSums`Private`b_:{MachinePrecision, MachinePrecision}] := 
    N[Zeta[3], HarmonicSums`Private`b]
 
Attributes[z5] = {Constant}
 
N[z5, HarmonicSums`Private`b_:{MachinePrecision, MachinePrecision}] := 
    N[Zeta[5], HarmonicSums`Private`b]
 
Attributes[z7] = {Constant}
 
N[z7, HarmonicSums`Private`b_:{MachinePrecision, MachinePrecision}] := 
    N[Zeta[7], HarmonicSums`Private`b]
