# -*- coding: utf-8 -*-

import pathlib

fps = pathlib.Path(__file__).parent.glob("*.c")
out = {}
for fp in fps:
    with open(fp, encoding="utf-8") as oi:
        nls = []
        # translate
        for l in oi:
            l = l.replace("Sigma_Summation_Objects_Private_MyPower","np.power")
            l = l.replace("Power", "np.power")
            l = l.replace("Log", "np.log")
            l = l.replace("ln2", "np.log(2)")
            l = l.replace("EulerGamma", "np.euler_gamma")
            l = l.replace("S(1.,n)", "S1")
            l = l.replace("S(2.,n)", "S2")
            l = l.replace("S(3.,n)", "S3")
            nls.append(l)
        out[fp.stem] = nls

    # output
    gamma_name, nf = str(fp).split('/')[-1].split('3')
    nf = nf[:-2]
    if gamma_name =="gqq":
        gamma_name = "gqqPS"
    eko_path = pathlib.Path(f"/Volumes/Git_Workspace/physicstools/NN3PDF/eko/src/eko/anomalous_dimensions/as4/tmp")
    eko_path.mkdir(exist_ok=True)
    with open(f"{eko_path}/{gamma_name}.py", "a", encoding="utf-8") as oo:
        # oo.write(
        #     "# -*- coding: utf-8 -*-\n"
        # )
        # oo.write("import numba as nb\n")
        # oo.write("import numpy as np\n")
        oo.write("\n\n")
        oo.write('@nb.njit(cache=True)\n')
        oo.write(f"def gamma_{gamma_name[1:]}_{nf}(n, sx):\n")
        oo.write("\tS1 = sx[0][0]\n")
        oo.write("\tS2 = sx[1][0]\n")
        oo.write("\tS3 = sx[2][0]\n")
        oo.write("\treturn ")
        for l in nls:
            oo.write(l)
        oo.write("\n\n")
